var Pessoa = /** @class */ (function () {
    function Pessoa(nome, idade, dataNascimento) {
        this._nome = nome;
        this._idade = idade;
        this._dataNascimento = dataNascimento;
    }
    Pessoa.prototype.getNome = function () {
        return this._nome;
    };
    Pessoa.prototype.getIdade = function () {
        return this._idade;
    };
    Pessoa.prototype.getDataNascimento = function () {
        return this._dataNascimento;
    };
    Pessoa.prototype.setNome = function (nome) {
        this._nome = nome;
    };
    Pessoa.prototype.setIdade = function (idade) {
        this._idade = idade;
    };
    Pessoa.prototype.setDataNascimento = function (dataNascimento) {
        this._dataNascimento = dataNascimento;
    };
    return Pessoa;
}());
