const pessoa = new Pessoa('Olivia', 20, new Date(2003, 3, 5));
console.log('Pessoa:');
console.log('Nome:', pessoa.getNome());
console.log('Idade:', pessoa.getIdade());
console.log('Data de Nascimento:', pessoa.getDataNascimento());

const pessoaFisica = new PessoaFisica('João', 25, new Date(1997, 4, 21), '123.456.789-00');
console.log('\nPessoa Física:');
console.log('Nome:', pessoaFisica.getNome());
console.log('Idade:', pessoaFisica.getIdade());
console.log('Data de Nascimento:', pessoaFisica.getDataNascimento());
console.log('CPF:', pessoaFisica.getCpf());

const pessoaJuridica = new PessoaJuridica('Empresa', 10, new Date(2012, 1, 5), '12.345.678/0001-00');
console.log('\nPessoa Jurídica:');
console.log('Nome:', pessoaJuridica.getNome());
console.log('Idade:', pessoaJuridica.getIdade());
console.log('Data de Nascimento:', pessoaJuridica.getDataNascimento());
console.log('CNPJ:', pessoaJuridica.getCnpj());